package pl.firma;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlRootElement;

@Entity
//@XmlRootElement
public class Billboard {
	
	@Id
	@GeneratedValue
//	@XmlAttribute
	int id;	
	String adres;
	
	@ManyToOne
	public Faktura faktura;
	
	@OneToMany(mappedBy="billboard",fetch = FetchType.EAGER)
	public List<Reklama> reklamy = new ArrayList<Reklama>();
	
	public Faktura getFaktura() {
		return faktura;
	}
	public void setFaktura(Faktura faktura) {
		this.faktura = faktura;
	}
	public List<Reklama> getReklama() {
		return reklamy;
	}
	public void setReklama(List<Reklama> reklamy) {
		this.reklamy = reklamy;
	}
	public String getAdres() {
		return adres;
	}
	public void setAdres(String adres) {
		this.adres = adres;
	}

}
