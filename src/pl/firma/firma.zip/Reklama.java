package pl.firma;

import java.math.BigDecimal;
import java.sql.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlRootElement;

@Entity
//@XmlRootElement
public class Reklama {
	
	@Id
	@GeneratedValue
//	@XmlAttribute
	int id;
	
	@ManyToOne
	Billboard billboard;
	
	String tresc;
	
	Date dataPowieszenia;
	Date dataSciagneicia;
	BigDecimal kwota;

	public Billboard getBillboard() {
		return this.billboard;
	}

	public void setBillboard(Billboard billboard) {
		this.billboard = billboard;
	}

	public String getTresc() {
		return this.tresc;
	}

	public void setTresc(String tresc) {
		this.tresc = tresc;
	}

}
